## Lists of Values

An *array* is a list of values.

```javascript
  var things = ["thing1", "thing2", "thing3"];
```

```javascript
  var letters = ["a", "b", "c"];
```

Show the first letter in the array.

```javascript
alert(letters[0]);
```

Show the second value in the array.

```javascript
alert(letters[1]);
```

Show the last value in the array.

```javascript
alert(letters[2]);
```
