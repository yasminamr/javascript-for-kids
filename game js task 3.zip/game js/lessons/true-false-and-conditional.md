## True and False Values

```javascript
  var good = true;
  var bad = false;
```

## Conditionals

If the statement is true, then do the instructions. Otherwise,
do something else.

```javascript
  if (good) {
    alert("yay!");
  } else {
    alert("boo!");
  }
```
